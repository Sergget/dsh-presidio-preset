"""文本归一化: 把写法变体折叠成标准形, 以便识别器命中。

真实文档里 PII 常被写成非标准形态:
  - 全角数字/字母 : 手机号写成 "１３８００１３８０００"
  - 数字插值     : "138 0013 8000" / "110101-19900307-7890" / 换行截断
  - 姓名插值     : "张 伟"

识别在归一化后的文本上做, 再用偏移映射把结果转回原文坐标,
这样占位符替换的是原文片段, 还原不受影响。

设计要点:
  - 只有「归一化前后一一对应」的变换才允许 (长度可缩短, 但不能合并语义单元);
  - 每个归一化字符都记录它在原文中的实际区间, 回填时取并集;
  - 不做简繁转换、不做 OCR 容错 (语义改变, 无法安全回填)。
"""
from __future__ import annotations

import re
import unicodedata
from typing import List, Tuple

# 数字之间常见的分隔符: 空白/换行、连字符系列、下划线。
# 不含点号 —— "192.168.1.100" 与 "user@example.com" 里的点是有意义的分隔,
# 吞掉会让 IP 与邮箱识别失败。
# 全部用 \u 转义书写, 避免源码里混入不可见字符导致规则歧义。
_SEP_CHARS = set(
    " \u0009\u000d\u000a"                          # 半角空格、Tab、CR、LF
    " 　    ﻿"        # 不换行/全角/窄空格、零宽
    "‐‑‒–—−"              # 连字符与破折号系列
    "-"                                            # ASCII 连字符 (最常被用到)
    "_"                                            # 下划线
)


def _is_digit(ch: str) -> bool:
    return (ch.isdigit() and ch.isascii()) or ch in "０１２３４５６７８９"


def _nfkc_char(ch: str) -> str:
    """单字符 NFKC 折叠: 全角数字/字母 -> 半角。"""
    folded = unicodedata.normalize("NFKC", ch)
    return folded if len(folded) == 1 else ch


# 已写完整的 11 位大陆手机号。归一化吞噬分隔符前用它卡一道:
# "王五 15385322046\n2024 年汇总" 里, 号码后的换行若被吞, 号码会与下一行
# 的数字粘成 "153853220462024", 手机号正则的 (?!\d) 右边界随即失效 → 裸漏。
# 插值写法的中间片段 ("138" / "1380013" / 身份证的 "11010119900307") 都不是
# 完整 11 位手机号, 不受影响, 仍照常拼接。
_RE_COMPLETE_MOBILE = re.compile(r"1[3-9]\d{9}")


def _trailing_is_complete_mobile(chars: List[str]) -> bool:
    """当前归一化串末尾的连续数字是否恰好是一个完整的 11 位手机号。

    最多回看 12 位: 第 12 位仍是数字说明不是「恰好 11 位」, 交回原吞噬逻辑
    (长数字串的插值拼接不受本判据影响)。
    """
    end = len(chars)
    start = end
    floor = max(0, end - 12)
    while start > floor and chars[start - 1].isdigit():
        start -= 1
    run = "".join(chars[start:end])
    return len(run) == 11 and _RE_COMPLETE_MOBILE.fullmatch(run) is not None


def normalize(text: str) -> Tuple[str, List[int], List[Tuple[int, int]]]:
    """归一化文本。

    返回 (归一化文本, norm_index -> 原文下标, norm_index -> 原文区间)。
    第二个数组用于把归一化坐标转回原文; 第三个用于取被折叠掉的原文片段
    (例如 "138 0013 8000" 里的空格, 替换时要一并吃掉)。
    """
    if not text:
        return "", [], []

    chars: List[str] = []
    origin: List[int] = []                # 归一化串下标 -> 原文下标
    spans: List[Tuple[int, int]] = []     # 归一化串下标 -> 原文区间 [start, end)

    i = 0
    n = len(text)
    while i < n:
        folded = _nfkc_char(text[i])

        if folded == "":
            # 零宽字符: 丢弃, 但并入前一个归一化字符的原文区间
            if spans:
                s, _e = spans[-1]
                spans[-1] = (s, i + 1)
            i += 1
            continue

        if folded in _SEP_CHARS:
            # 分隔符: 夹在两个数字之间且**只有一个字符**时才吞噬
            # ("138 0013 8000" / "11010119900307\n7890")。
            # 连续多个空白是表格列对齐, 吞掉会把几列数字拼成伪卡号
            # (Get-Process 输出 "200      12    40960  20480     1.25" 曾被判成 BANK_CARD)。
            prev_digit = bool(chars) and chars[-1].isdigit()
            j = i + 1
            next_is_sep = j < n and _nfkc_char(text[j]) in _SEP_CHARS
            next_digit = j < n and _nfkc_char(text[j]).isdigit()
            # 关键: 左侧已是一个**完整**手机号时不得再吞, 否则列表末项
            # 紧跟换行/空格 + 数字开头文本会粘成超长串, 边界正则失效漏检。
            complete_mobile = prev_digit and _trailing_is_complete_mobile(chars)
            if prev_digit and next_digit and not next_is_sep and not complete_mobile:
                if spans:
                    s, _e = spans[-1]
                    spans[-1] = (s, j)
                i = j
                continue
            # 不是可吞噬的数字间分隔符: 保留为普通空格
            chars.append(" ")
            origin.append(i)
            spans.append((i, i + 1))
            i += 1
            continue

        chars.append(folded)
        origin.append(i)
        spans.append((i, i + 1))
        i += 1

    return "".join(chars), origin, spans


def to_original(start: int, end: int, origin: List[int],
                spans: List[Tuple[int, int]]) -> Tuple[int, int]:
    """把归一化坐标 [start, end) 转回原文坐标。

    归一化串末尾字符的原文区间末端作为结束位置, 以便把被吞噬的
    尾随分隔符也纳入替换范围 ("138 0013 8000" -> 整体替换)。
    """
    if not origin or start >= len(origin):
        return start, end
    orig_start = origin[start]
    last = min(end - 1, len(spans) - 1)
    orig_end = spans[last][1] if last >= 0 else origin[start] + 1
    return orig_start, max(orig_end, orig_start + 1)


class NormalizedText:
    """归一化文本及其偏移映射, 供识别器使用。"""

    __slots__ = ("text", "origin", "spans", "changed")

    def __init__(self, text: str):
        self.text, self.origin, self.spans = normalize(text)
        self.changed = self.text != text

    def back(self, start: int, end: int) -> Tuple[int, int]:
        return to_original(start, end, self.origin, self.spans)
