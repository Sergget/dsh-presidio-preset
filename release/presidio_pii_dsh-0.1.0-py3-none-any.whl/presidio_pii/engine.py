"""轻量 Presidio 引擎封装 (零 spaCy 依赖)。

核心概念遵循 Microsoft Presidio:
  - Recognizer.analyze(text) -> List[RecognizerResult]
  - AnalyzerEngine : 聚合多 Recognizer 的结果
  - AnonymizerEngine : 替换实体为占位符
  - 还原 : 利用 SessionRegistry 的映射

占位符格式 : ⟦PII:<TYPE>:<SEQ>⟧  (Unicode 边界, 抗 LLM 篆改)
"""
from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from typing import Dict, List

from .chinese_recognizers import RecognizerResult, get_chinese_recognizers
from .custom_rules import CustomRuleSet
from .db import SessionRegistry
from .normalize import NormalizedText

PH_OPEN, PH_CLOSE = "⟦", "⟧"
_PH_RE = re.compile(r"⟦PII:[A-Z_]+:\d+⟧")
# UUID: 数字类识别器在它内部只会切走一段, 必须整体跳过而不是局部替换
_RE_UUID = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")


def count_placeholders(text: str) -> int:
    """统计文本中残留的占位符数量 (用于还原后校验)。"""
    return len(_PH_RE.findall(text))

# 实体优先级 (重叠冲突时使用: 数字越小优先级越高)
# 裁决顺序: 先取更长的实体 ("安徽省数据资源管理局" 不被其中的 "安徽省" 切碎),
# 等长时再按本优先级 — 证件号优先于银行卡 (15 位身份证不应被判成卡号),
# 人名高于机构名 (防止人名被机构名整体吞掉),
# 地名高于人名 (地名 "北京市朝阳区" 比误切的人名更精确)
_PRIO = {"ID_NUMBER": 0, "CREDIT_CODE": 1, "PASSPORT": 2, "PHONE_NUMBER": 3,
         "EMAIL_ADDRESS": 4, "LICENSE_PLATE": 5, "BANK_CARD": 6, "LOCATION": 7,
         "PERSON": 8, "JOB_TITLE": 9, "ORGANIZATION": 10,
         "IP_ADDRESS": 11, "MAC_ADDRESS": 12}


@dataclass
class RedactResult:
    text: str
    session_id: str
    doc_id: str
    n_replaced: int = 0
    restored: Dict[str, str] = field(default_factory=dict)
    unrestored: Dict[str, str] = field(default_factory=dict)
    entity_counts: Dict[str, int] = field(default_factory=dict)
    n_whitelisted: int = 0


class PresidioPIIEngine:
    """零 spaCy 依赖的轻量引擎, API 兼容 Microsoft Presidio 概念。

    whitelist: 受保护的关键词列表。命中白名单的区域不会被脱敏,
    与白名单区域重叠的实体一并跳过 (例如白名单含 "合肥市数据资源局" 时,
    其中的 "合肥市" 也不会被单独脱敏)。

    custom_rules 支持四种形态:
      - None: 从 PII_DSH_CUSTOM_RULES 环境变量加载 (可热更新)
      - str: 规则文件路径 (分号/逗号分隔, 可热更新)
      - CustomRuleSet: 直接使用调用方管理的规则集合
      - list: 已加载的静态规则列表 (不监控文件变更)
    rules_check_interval: 热更新检查间隔 (秒), <=0 关闭自动检查。
    """

    @staticmethod
    def _known_entity_types(rule_set) -> set:
        """当前合法实体类型全集 = 内置识别器类型 ∪ 自定义规则类型。"""
        builtin = {getattr(rec, "entity_type", None) for rec in get_chinese_recognizers()}
        custom = {getattr(r, "entity_type", None) for r in rule_set.rules}
        return {t for t in (builtin | custom) if t}

    def _sanitize_entity_types(self, types) -> set:
        """过滤掉未知/拼错的实体类型名，避免误配置导致静默零脱敏。"""
        raw = {t for t in (types or []) if t}
        if not raw:
            return set()
        known = self._known_entity_types(self._rule_set)
        valid = {t for t in raw if t in known}
        unknown = raw - valid
        if unknown:
            print(f"[pii] 忽略未知实体类型 {sorted(unknown)}；合法类型: {sorted(known)}",
                  file=sys.stderr)
        # 全部无效 → 归一为空集合，_filter_entity_types 视为全开（fail toward 多脱敏）
        return valid

    def __init__(self, db_path=None, whitelist=None, custom_rules=None,
                 rules_check_interval: float = 1.0, entity_types=None):
        self._builtin_recognizers = get_chinese_recognizers()
        if isinstance(custom_rules, CustomRuleSet):
            self._rule_set = custom_rules
        elif isinstance(custom_rules, str):
            self._rule_set = CustomRuleSet(custom_rules,
                                           check_interval=rules_check_interval)
        elif custom_rules is not None:
            self._rule_set = CustomRuleSet.from_rules(custom_rules)
        else:
            self._rule_set = CustomRuleSet(check_interval=rules_check_interval)
        self.registry = SessionRegistry(db_path) if db_path else SessionRegistry()
        self.whitelist = [w for w in (whitelist or []) if w]
        # 只保留用户勾选的实体类型; None/空 = 全开（保持默认行为向后兼容）。
        # 未知/拼错的类型名会被告警忽略；若配置的全部类型都无效，归一为空集合（全开），
        # 避免把识别结果全部过滤掉造成静默零脱敏（fail-open 漏 PII）。
        self.entity_types = self._sanitize_entity_types(entity_types)
        self._sync_recognizers()

    @property
    def custom_rules(self) -> List:
        """当前生效的自定义规则 (热更新后会变化)。"""
        return self._rule_set.rules

    def _sync_recognizers(self) -> None:
        """重建识别器列表与优先级表 (规则热更新后调用)。"""
        self.recognizers = self._builtin_recognizers + list(self._rule_set.rules)
        # 自定义类型可覆盖同名内置类型的优先级; 未声明的类型仍按 99 兜底
        self._prio = {**_PRIO, **self._rule_set.entity_priorities()}

    def reload_custom_rules(self, force: bool = True) -> int:
        """显式重载自定义规则, 返回当前规则条数。

        force=False 时仍受 rules_check_interval 节流。静态规则列表不受影响。
        """
        if self._rule_set.refresh(force=force):
            self._sync_recognizers()
        return len(self._rule_set)

    def set_whitelist(self, terms) -> None:
        self.whitelist = [w for w in (terms or []) if w]

    def set_entity_types(self, types) -> None:
        """设置启用的实体类型集合; 传 None 或空集合表示全部启用。

        未知/拼错的类型名被告警忽略；全部无效时归一为空集合（全开），
        避免热更新把合法类型换成拼错类型后静默零脱敏。
        """
        self.entity_types = self._sanitize_entity_types(types)

    # ---- 白名单 ----
    def _protected_spans(self, text: str) -> List[tuple]:
        """白名单词在文本中的所有出现位置 (start, end)。"""
        spans = []
        for term in self.whitelist:
            start = text.find(term)
            while start != -1:
                spans.append((start, start + len(term)))
                start = text.find(term, start + 1)
        return spans

    @staticmethod
    def _drop_protected(results: List[RecognizerResult], spans: List[tuple]):
        """丢弃与白名单区域重叠的实体, 返回 (保留的实体, 被跳过的数量)。"""
        if not spans:
            return results, 0
        kept = [r for r in results
                if not any(r.start < e and r.end > s for s, e in spans)]
        return kept, len(results) - len(kept)

    # ---- 分析 ----
    def analyze(self, text: str) -> List[RecognizerResult]:
        """识别文本中的 PII, 返回按文本顺序排列的结果。

        先在归一化文本上识别 (折叠全角字符与数字间插值), 再把坐标转回原文,
        因此 "１３８００１３８０００"、"138 0013 8000" 这类写法也能命中,
        且替换的是原文片段。
        """
        if not text:
            return []
        if self._rule_set.refresh():
            self._sync_recognizers()  # 规则文件变了: 重建识别器与优先级表
        norm = NormalizedText(text)
        probe = norm.text if norm.changed else text
        results: List[RecognizerResult] = []
        for rec in self.recognizers:
            # 自定义规则 (wants_raw) 按约定在原文上匹配并返回原文坐标;
            # 内置识别器在归一化文本上识别, 命中后映射回原文坐标
            results.extend(rec.analyze(text if getattr(rec, "wants_raw", False) else probe))
        if norm.changed:
            mapped = []
            for r in results:
                start, end = norm.back(r.start, r.end)
                if start < 0 or end > len(text) or start >= end:
                    continue
                mapped.append(RecognizerResult(start, end, r.entity_type, r.score))
            results = mapped
        # 去重 & 冲突处理 (使用含自定义优先级的表)
        results = self._trim_spans(text, results)
        results = self._drop_uuid_spans(text, results)
        results = self._filter_entity_types(results)
        return self._resolve_overlaps(results, self._prio)

    def _filter_entity_types(self, results: List[RecognizerResult]) -> List[RecognizerResult]:
        """按 preset 的 entity_types 白名单过滤; 空集合表示不限制。

        在冲突消解**之前**过滤, 这样被关掉的类型不会抢占同区间的其他类型
        （例如关掉 LOCATION 后, 该区间的 ORGANIZATION 仍能被正常识别脱敏）。

        自定义规则产出的类型（USER_TERM 等）**始终保留**：它们是用户显式
        配置的屏蔽词, 不该被内置类型的勾选列表顺手关掉。
        """
        if not self.entity_types:
            return results
        custom = {getattr(r, "entity_type", None) for r in self._rule_set.rules}
        allowed = self.entity_types | {t for t in custom if t}
        return [r for r in results if r.entity_type in allowed]

    @staticmethod
    def _trim_spans(text: str, results: List[RecognizerResult]) -> List[RecognizerResult]:
        """剥离实体区间首尾的空白/换行。

        某些识别器 (如人名三字窗口、jieba 词性标注) 会把尾随空格/制表符/换行
        并进实体, 直接替换会吞掉原文的分隔符, 破坏分行、缩进与表格对齐。
        只裁首尾, 实体内部的空格 ("张 伟") 保持不变。
        """
        out = []
        for r in results:
            start, end = r.start, r.end
            while start < end and text[start].isspace():
                start += 1
            while end > start and text[end - 1].isspace():
                end -= 1
            if end <= start:
                continue
            out.append(r if (start, end) == (r.start, r.end)
                       else RecognizerResult(start, end, r.entity_type, r.score))
        return out

    @staticmethod
    def _drop_uuid_spans(text: str, results: List[RecognizerResult]) -> List[RecognizerResult]:
        """丢弃落在 UUID 内部的实体: UUID 要么整体脱敏, 要么整体保留。

        数字类识别器无法把 UUID 整体识别成一个实体, 局部替换会既泄露前段
        又把 ID 弄坏, 因此统一跳过 (与 git hash 的边界规则互补)。
        """
        spans = [m.span() for m in _RE_UUID.finditer(text)]
        if not spans:
            return results
        return [r for r in results
                if not any(r.start < sp_end and r.end > sp_start
                           for sp_start, sp_end in spans)]

    @staticmethod
    def _resolve_overlaps(results: List[RecognizerResult],
                          prio: Dict[str, int] | None = None) -> List[RecognizerResult]:
        if not results:
            return []
        priority = _PRIO if prio is None else prio
        # 长实体优先: "安徽省数据资源管理局" 应整体保留, 不被其中的 "安徽省" 切碎;
        # 等长时按优先级, 再按起点, 保证结果稳定
        results.sort(key=lambda r: (-(r.end - r.start),
                                    priority.get(r.entity_type, 99), r.start))
        merged: List[RecognizerResult] = []
        for r in results:
            if not any(r.start < m.end and r.end > m.start for m in merged):
                merged.append(r)
        # 还原为文本顺序
        merged.sort(key=lambda r: r.start)
        return merged

    # ---- 脱敏 ----
    def redact(self, text: str, session_id: str, doc_id: str = "default",
               counters: Dict[str, int] | None = None,
               commit: bool = True) -> RedactResult:
        """脱敏单段文本。

        counters 可在同一文档的多次调用间复用 (跨单元共享序号),
        首次遇到某实体类型时才查询映射库, 避免逐单元重复 MAX(seq) 查询。
        commit=False 时把提交推迟到调用方, 批量写库时避免逐单元 fsync。
        """
        results = self.analyze(text)  # 已按文本顺序排序
        skipped = 0
        if self.whitelist:
            results, skipped = self._drop_protected(results, self._protected_spans(text))
        # 序号在会话内全局递增 (跨多次 redact 调用), 避免多轮对话占位符冲突
        if counters is None:
            counters = {res.entity_type: self.registry.get_max_seq(session_id, res.entity_type)
                        for res in results}
        else:
            for res in results:
                if res.entity_type not in counters:
                    counters[res.entity_type] = self.registry.get_max_seq(session_id, res.entity_type)
        restored: Dict[str, str] = {}
        entity_counts: Dict[str, int] = {}
        plan = []  # (result, placeholder, original)
        for res in results:
            ptype = res.entity_type
            counters[ptype] = counters.get(ptype, 0) + 1
            ph = f"{PH_OPEN}PII:{ptype}:{counters[ptype]:04d}{PH_CLOSE}"
            orig = text[res.start:res.end]
            plan.append((res, ph, orig))
            restored[ph] = orig
            entity_counts[ptype] = entity_counts.get(ptype, 0) + 1

        # 逆序替换以避免 offset 漂移
        out_text = text
        for res, ph, _orig in reversed(plan):
            out_text = out_text[:res.start] + ph + out_text[res.end:]

        # 映射入库 (idx 按文本顺序); 整批提交, 避免逐条 commit 的磁盘同步开销
        for idx, (res, ph, orig) in enumerate(plan):
            self.registry.add_mapping(session_id, doc_id, idx,
                                      res.entity_type, ph, orig, commit=False)
        if plan and commit:
            self.registry.commit()

        return RedactResult(text=out_text, session_id=session_id, doc_id=doc_id,
                            n_replaced=len(plan), restored=restored,
                            entity_counts=entity_counts, n_whitelisted=skipped)

    # ---- 还原 ----
    def restore(self, text: str, session_id: str, doc_id: str = "default",
                mapping: List[Dict] | Dict[str, str] | None = None,
                collect_unrestored: bool = True) -> RedactResult:
        """还原文本中的占位符。

        mapping 可传入已取好的映射 (列表或 占位符->原文 字典), 批量还原时只构建一次。
        collect_unrestored=False 时跳过"未命中"统计 (批量还原按整篇统计时用)。
        只扫描文本中实际出现的占位符, 成本与占位符数量成正比, 与映射表大小无关。
        """
        if mapping is None:
            mapping = self.registry.get_restore_map(session_id, doc_id)
        by_ph = mapping if isinstance(mapping, dict) else \
            {m["placeholder"]: m["original"] for m in mapping}

        out = text
        restored: Dict[str, str] = {}
        for ph in _PH_RE.findall(text):
            if ph in restored:
                continue
            orig = by_ph.get(ph)
            if orig is None:
                continue
            out = out.replace(ph, orig)
            restored[ph] = orig

        unrestored = ({ph: orig for ph, orig in by_ph.items() if ph not in restored}
                      if collect_unrestored else {})
        return RedactResult(text=out, session_id=session_id, doc_id=doc_id,
                            restored=restored, unrestored=unrestored)
